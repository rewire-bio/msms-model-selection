# Access and feasibility gate: article 335, MS/MS molecular shortlisting

Prepared 2026-10-03/04 by the coordinator (Claude Opus, claude-opus-5-5). All checks below were run on this machine (Apple M4, 10 cores, 16 GB RAM, macOS, no CUDA) unless marked otherwise. Receipts live in `evidence/receipts/`, `runs/data/downloads/` and the per-run directories under `runs/`. No test-fold outcome was inspected before `evidence/protocol.md` was frozen.

## 1. Verdict

| Item | Status | Consequence |
|---|---|---|
| MSAlign paper | arXiv 2605.19752 **v2 (25 Sep 2026)** is current; v1 (19 May 2026) differs materially | Use v2 as the published comparator; record v1 to v2 changes |
| Official code | github.com/KrzakalaPaul/MSAlign-NeurIPS2026, commit `c2ef425b6874`, MIT | Executable on CPU/MPS for MSAlign, DeepSets and Emb-Cos paths |
| Processed data, splits, candidates | Zenodo 10.5281/zenodo.22830464, `massspecgym.zip`, CC BY 4.0, MD5 verified | Exact 256-candidate MassSpecGym setting is reproducible |
| Released MSAlign checkpoints | **Not released** (paper checklist: "will be released upon publication") | No released-weight inference is possible; all learned models here are newly trained |
| Published MSAlign (DreaMS + MolDeBERTa) | **Not executed.** MolDeBERTa weights are downloadable anonymously but licensed CC BY-NC-ND 4.0, and the released layout needs molecule embeddings for 6.42 M distinct candidate structures (about 19.7 GB float32 as unique vectors, about 22.7 GB in the released per-target padded cache) | Exceeds free disk; reported as published numbers only |
| Eligible released MSAlign configuration | **DreaMS + Morgan fingerprint** pair, trained with the released code and released hyperparameters (v2 Table 4 and Table 11 report 38.6 ± 2.8 R@1 on the formula split) | Executed as the learned alignment model, labelled "newly trained" |
| DreaMS spectrum embeddings | Released on Zenodo for all 231,104 MassSpecGym spectra (`dreams.npy`) | No DreaMS inference needed for benchmark scoring |
| DeepSets (fingerprint predictor) | In released `model_zoo` | Executed (newly trained) |
| Emb-Cos | In released `model_zoo` | Executed (newly trained) if the timing smoke supports the full budget |
| FFN | Not in released v2 code (v2 Table 3 dropped it); MassSpecGym paper reports it | Published numbers only |
| JESTR, FLARE, MVP | Released but require DGL 2.1 CUDA 12.1 Linux wheel | Not executable here; published numbers only |
| SAIL, NPLIB1 | Present in v1 Table 3, absent from v2 and from the released code | Published (v1) numbers only, flagged as superseded |
| Spectraverse | Zenodo `spectraverse.zip` 2.24 GB; not needed for the scoped question | Not downloaded; published numbers only |
| Formula-informed methods (MIST, FLARE, MVP, MSAlign+Filter) | Require the target's true formula (an oracle) | Separate track, never compared with formula-free rows |

## 2. Paper versions

- v1: `research/automated-research/original-sources/msalign-2605.19752v1.pdf`, SHA-256 `7395a55141ee7916741b7d9e6d4f42a1d3a03217a36ce6824ac3ff48afd4f26f` (identical hash to the copy previously audited in the rewire-database catalogue).
- v2: `.../msalign-2605.19752v2.pdf`, SHA-256 `a31d1167b0ded72f64717881dd6cba0946a56b495d76f169d8e44115c3266fda`.
- Line-stable text: `research/automated-research/original-sources-text/msalign-2605.19752v{1,2}.txt` (pdftotext -layout, form feeds removed so that line numbers count LF only).

Material v1 to v2 changes (v1 is what the rewire catalogue and the issue plan describe):

| Aspect | v1 (May 2026) | v2 (Sep 2026, NeurIPS 2026 camera-ready) |
|---|---|---|
| Molecule encoder | ChemBERTa | MolDeBERTa (v2 Table 1 still prints ChemBERTa in one row; text, Table 4 and Table 8 use MolDeBERTa) |
| Formula-free columns of Table 3 | FFN, DeepSets, JESTR, Emb-Cos, SAIL, MSAlign | DeepSet, JESTR, Emb-Cos, MSAlign, fused MSAlign (7 scores) |
| Datasets | NPLIB1, Spectraverse, MassSpecGym formula, MassSpecGym MCES | Spectraverse, MassSpecGym formula, MassSpecGym MCES |
| Uncertainty | none | mean ± SD over 3 formula split seeds (MCES: 2 val/test swaps) |
| MassSpecGym formula R@1, DeepSets | 22.2 | 4.7 ± 0.6 |
| MassSpecGym formula R@1, Emb-Cos | 41.2 | 42.7 ± 3.0 |
| MassSpecGym formula R@1, MSAlign | 53.8 | 47.5 ± 3.4 (standalone); 58.2 ± 3.4 fused |
| Mass-based scorers | absent | three Gaussian ppm scorers (sigma 0.01, 0.1, 1 ppm) inside the fused model |

The issue plan's "six exact formula-free configurations in Table 3" therefore describes v1. All six were checked: FFN and SAIL exist only in v1; DeepSets, JESTR, Emb-Cos and MSAlign exist in both but with different numbers. The rewire catalogue's 108 v1 cells were verified previously (`rewire-database-use-case-coverage/docs/omics/model-evaluation-coverage-2026-09-23/mimic-msalign-review.md`); that review predates v2.

## 3. Downloads and hashes

| Artifact | Source and revision | Size | Hash | Licence |
|---|---|---|---|---|
| `massspecgym.zip` | Zenodo record 22830464 (published 2026-09-18) | 1,078,913,065 B | MD5 `96e8b1885cf4120aaef93154ce809cbd` (matches Zenodo API); SHA-256 `6dbe62b0e692...91f1` | CC BY 4.0 |
| Extracted members (35 files, `annotated_peaks.json` skipped) | same | 1.53 GB | `runs/data/downloads/extracted-sha256.txt` | CC BY 4.0 |
| `MassSpecGym.tsv` | HF dataset `roman-bushuiev/MassSpecGym` @ `d2e86d0c3bd9` | 262 MB | SHA-256 listed by HF `0c9cc504...bcd95`; receipt in `runs/data/downloads/` | MIT |
| `MassSpecGym_retrieval_molecules_4M.tsv` | same revision | 309 MB | HF SHA-256 `1f8ca235...abf`; receipt in `runs/data/downloads/` | MIT |
| MSAlign source | GitHub, commit `c2ef425b68749052a17b9cdd5f5f11709322654e` | 1.2 MB | git object id | MIT |
| DreaMS weights (own-input path only) | HF `roman-bushuiev/DreaMS` @ `c81a62766b10`: `DreaMS_embedding_model_torchscript.pt` 468 MB, SHA-256 `df698669...0f`; `embedding_model.ckpt` 1.24 GB, SHA-256 `630ba2e5...12f4` | see left | HF LFS SHA-256 | MIT |
| MolDeBERTa | HF `SaeedLab/MolDeBERTa-base-123M-mtr` @ `7d06a5f3`; `config.json` fetched anonymously (HTTP 200) | 123 M params | not downloaded | CC BY-NC-ND 4.0 |

Zenodo zip listing (with CRCs) was read by HTTP range requests before the download: `evidence/receipts/zenodo-massspecgym-zip-listing.txt`. The bundle contains `dreams.npy` (231,104 x 1024 float32), Morgan fingerprints for the 28,936 labelled molecules only, an empty `mol_embeddings/` directory, the official mass candidate map, and 25 split files (formula, InChIKey, Murcko, Murcko-histogram and random, 5 seeds each; MCES 1 and 2).

## 4. Data audit (train and validation folds only, plus fold sizes)

Commands: inline Python in the session, reproduced in `companion/scripts/audit_data.py`.

- 231,104 spectra; 28,936 distinct 2D SMILES after MSAlign normalisation; adducts [M+H]+ 195,237 and [M+Na]+ 35,867 (15.5% non-[M+H]+). Charge is +1 for both adducts.
- `formula_seed1`: train 210,825 spectra / 26,087 molecules; validation 9,631 / 1,428; test 10,648 / 1,421. `mces_1`: 194,119 / 22,755; 19,429 / 3,184; 17,556 / 2,997. Seeds 2 and 3 have similar sizes. Zenodo also ships seeds 0 and 4, unused by the paper.
- Candidate map: 29,307 targets; all 28,936 labelled molecules present; candidate zero is the target in every list; 97.4% of lists have exactly 256 entries; minimum 12.
- **Stereochemistry is removed** (canonical, non-isomeric SMILES). No candidate or target SMILES carries `@`, `/` or `\`. The task is therefore 2D structure retrieval: stereoisomers are not distinguished.
- **Duplicate structures inside candidate lists**: after stereo removal, 24,713 of 28,936 lists (85.4%) contain at least one repeated decoy SMILES (mean 6.9, maximum 121 repeated entries per list; median 253 distinct structures). The target is never repeated in its own list. Released metrics count each duplicate separately.
- **Precursor m/z provenance is mixed**. Neutral mass estimated as precursor m/z minus the adduct offset (1.007276 for [M+H]+, 22.989221 for [M+Na]+), compared with RDKit exact mass of the annotated structure: training fold |ppm error| median 0.22, 90th percentile 7.4, 99th 24.6; 19.0% within 0.01 ppm, 66.7% within 1 ppm, 92.9% within 10 ppm. Validation: 20.5% within 0.01 ppm, median 0.15 ppm. A fifth of records carry a precursor value that matches the theoretical mass to within 0.01 ppm, which is far tighter than instrument accuracy and indicates values recomputed from the annotation in the source libraries. Decimal places of the stored value range from 1 to 14.
- About one third (32.6%) of distinct decoys in validation lists have exactly the target's monoisotopic mass (isomers), so no mass rule can separate them.

### Is mass-error ranking informative under equal inputs?

Validation fold of `formula_seed1`, distinct structures, rank by |ppm| between adduct-corrected precursor mass and candidate exact mass:

| Tie rule | R@1 | R@5 | R@20 |
|---|---|---|---|
| Expected value under random tie-breaking | 3.79% | 14.60% | 35.61% |
| Strict (a tied decoy beats the target, as in the released evaluation) | 0.80% | 6.41% | 18.78% |
| Random ordering, expected | 0.42% | 2.08% | 8.31% |

Mass-error ranking uses only precursor m/z, adduct and charge, which every compared method also receives. It is informative, so it enters the panel as the cheap baseline. Its value depends heavily on the tie rule and partly on the recomputed precursor values; both facts are carried into the protocol. The v2 paper's single mass scorers (0.6 to 0.8% R@1, Table 11) are consistent with the strict rule.

## 5. Pretraining and leakage audit

- DreaMS backbone: self-supervised on GeMS (unlabelled MassIVE spectra). The `DreaMS_embedding` checkpoint used to produce `dreams.npy` (MSAlign `preprocessing/encode_dreams.py` calls `PreTrainedModel.from_name("DreaMS_embedding")`) was contrastively fine-tuned with structure-derived positives on MoNA spectra (`dreams/training/fine_tune.sh` at DreaMS commit `dbec3a0`, dataset `MoNA_A_Murcko_split_neighbours_[M+H]+_0.05Da.pkl`). MassSpecGym includes MoNA spectra. Some formula-split test molecules may therefore have informed the frozen spectrum encoder. The MoNA fine-tuning membership list is not released, so the overlap cannot be quantified here. A separate `embedding_model_massspecgym.ckpt` exists on HF but MSAlign does not use it.
- Morgan fingerprints and binned spectra have no pretraining.
- MolDeBERTa (not executed) was pretrained on up to 123 M PubChem SMILES, which include MassSpecGym candidates and targets as unlabelled structures.
- Supervised leakage: the formula split guarantees no shared molecular formula across folds; the MCES split enforces MCES distance of at least 10.

## 6. Compute feasibility

| Job | Measured or estimated | Basis |
|---|---|---|
| Candidate Morgan fingerprint cache (28,936 x 256 x 512 B) | 239 s wall, 4 workers, 1.79 GB peak RSS; 987 MB with LZF compression (3.8 GB uncompressed) | `runs/R01-candidate-fingerprints-*/log.txt` |
| DreaMS + Morgan MSAlign, 60-step smoke plus full validation pass and checkpoint save | 165 s wall; about 1.1 steps/s on MPS after warm-up; validation pass (9,631 spectra x up to 256 candidates) about 50 s; 5.9 GB peak RSS; checkpoint 298 MB with optimiser state | `runs/S02-smoke-dreams-morgan-*` (S01 incomplete: disk-full warning, ended mid-validation, no checkpoint) |
| DreaMS + Morgan full released budget (30,000 steps, validation each epoch of 1,647 steps) | about 8 to 9 h estimated | from S02 step rate |
| DeepSets + Fourier, smoke (3,000 training spectra, 1 epoch, 300 val, 300 val-as-test) | 83 s wall; 26.5 steps/s at batch 16; 1.5 GB peak RSS | `runs/S03-smoke-deepsets-*` |
| DeepSets full released budget (50 epochs x 13,177 steps) | about 7.5 h estimated | from S03 step rate |
| Emb-Cos smoke (100 steps) | 213 s wall; 1.6 steps/s (fingerprints computed on the fly with RDKit); 5.3 GB peak RSS | `runs/S04-smoke-embcos-*` |
| Emb-Cos full released budget (16,000 steps) | about 3 h estimated | from S04 step rate |

The smoke split `smoke_formula_seed1_valonly.csv` (3,000 train rows, 300 validation rows, 300 further validation rows labelled "test", all others "unused") was added to the data directory so that the released scripts, which always evaluate a "test" fold at the end, never touched real test rows before the protocol freeze. Smoke configs `model_zoo/{DeepSets,EmbCos}/configs/smoke.yaml` change only the epoch or step budget.

The three full runs are queued strictly one after another by `companion/scripts/queue_training.sh` (started 2026-10-04 22:09 UTC, after the protocol freeze at 22:07 UTC).

Storage patch: `runs/patches/msalign-c2ef425-lzf-fingerprint-cache.diff` adds `compression="lzf"` to the HDF5 candidate fingerprint dataset. It changes storage only; read values are identical.

## 7. Remaining gaps

1. Published MSAlign (DreaMS + MolDeBERTa) and the fused MSAlign cannot be executed locally (no weights; MolDeBERTa licence and 20+ GB embedding cache).
2. JESTR, FLARE and MVP need a Linux CUDA DGL stack.
3. One formula split seed (seed 1) is executed; the paper averages three. Seed-to-seed variation is quoted from the paper, not reproduced.
4. The DreaMS MoNA fine-tuning overlap with the test fold cannot be measured.
5. MassSpecGym records precursor m/z inconsistently (some recomputed), which flatters mass-error ranking relative to measured data.
6. No independent instrument-held-out set was run. NPLIB1 and Spectraverse are not used.
