superseded by M02 (instrument assignment rule widened)
