# S01 status: INCOMPLETE (not a result)

Bounded smoke run of the released MSAlign code with the DreaMS-Morgan pair, formula_seed1, 150 steps.
Training reached 150/150 steps in 3 min 02 s (steady state ~0.8-1.0 steps/s on Apple M4 MPS, 3 loader workers).
macOS reported "volume out of space" while writing MPS graph caches (free disk was ~9.5 GiB at the time).
The session ended during the first validation pass (33/602 batches). No checkpoint or metrics were written.
Not used for any reported number. Superseded for smoke purposes by S02.
