FAILED: AssertionError on adduct vocabulary size (n_adducts includes the unknown slot). Fixed in score_pools.py; superseded by H02.
