# H02 status: PASS (harness check, validation only)

Smoke checkpoint S02 (60 steps) scored with companion/scripts/score_pools.py on formula_seed1 validation (9,631 spectra), P00 pools.
Released trainer logged R@1/val 0.171, R@5/val 0.365, R@20/val 0.571 for this checkpoint.
Harness, official_raw pool, strict ties: 0.1712, 0.3650, 0.5714. Protocol section 8 requirement (match within 0.1 pp) met.
Smoke model only; not a result.
